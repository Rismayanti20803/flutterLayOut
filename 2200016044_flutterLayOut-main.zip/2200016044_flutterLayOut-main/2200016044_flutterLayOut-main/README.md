## Nuriyah Syarifah
## 2100016030
## Kelas D
